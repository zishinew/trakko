Original synthesized demo audio by Trakko. Illustrative demo stems, royalty-free.
